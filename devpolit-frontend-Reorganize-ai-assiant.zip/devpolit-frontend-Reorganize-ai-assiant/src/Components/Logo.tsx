import React from "react";
import { Flex, Image } from "@chakra-ui/react";

const Logo: React.FC = () => {
  return (
    <Flex p={4}>
      <Image src="/src/assets/images/Logo.png" alt="Logo" height="40px" />
    </Flex>
  );
};

export default Logo;
