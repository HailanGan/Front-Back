import React, { useState } from "react";
import {
  ListItem,
  Flex,
  Text,
  IconButton,
  Input,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
} from "@chakra-ui/react";
import { HiOutlineDotsHorizontal } from "react-icons/hi";

interface Chat {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  folderId?: string;
}

interface ChatItemProps {
  chat: Chat;
  onRenameChat: (newName: string) => void;
  onDeleteChat: () => void;
}

const ChatItem: React.FC<ChatItemProps> = ({ chat, onRenameChat, onDeleteChat }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(chat.content);
  const [isDragging, setIsDragging] = useState(false);

  const handleRename = () => {
    if (editValue.trim() !== "") {
      onRenameChat(editValue.trim());
      setIsEditing(false);
    }
  };

  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData("text/plain", chat.id);
    e.dataTransfer.setData("chatData", JSON.stringify(chat));
    setIsDragging(true);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
  };

  return (
    <ListItem
      p={2}
      bg={isDragging ? "gray.100" : "white"}
      borderRadius="md"
      boxShadow="sm"
      draggable
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      sx={{
        cursor: "grab",
        "&:active": { cursor: "grabbing" },
        opacity: isDragging ? 0.5 : 1,
        transition: "all 0.2s",
        border: "1px solid transparent",
        "&:hover": {
          bg: "gray.50",
          borderColor: "blue.200"
        }
      }}
    >
      <Flex justify="space-between" align="center">
        {isEditing ? (
          <Input
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            onBlur={handleRename}
            onKeyPress={(e) => {
              if (e.key === "Enter") {
                handleRename();
              }
            }}
            autoFocus
            size="sm"
            onClick={(e) => e.stopPropagation()}
          />
        ) : (
          <Text flex="1">{chat.content}</Text>
        )}

        <Menu>
          <MenuButton
            as={IconButton}
            icon={<HiOutlineDotsHorizontal />}
            variant="ghost"
            size="sm"
            aria-label="Options"
            onClick={(e) => e.stopPropagation()}
            sx={{
              "&:hover": { bg: "gray.200" }
            }}
          />
          <MenuList>
            <MenuItem
              onClick={() => {
                setIsEditing(true);
                setEditValue(chat.content);
              }}
            >
              Rename
            </MenuItem>
            <MenuItem onClick={onDeleteChat}>Delete</MenuItem>
          </MenuList>
        </Menu>
      </Flex>
    </ListItem>
  );
};

export default ChatItem;