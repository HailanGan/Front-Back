import React, { useState } from "react";
import {
  Accordion,
  AccordionItem,
  AccordionButton,
  AccordionPanel,
  AccordionIcon,
  Flex,
  Text,
  IconButton,
  Input,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Box,
} from "@chakra-ui/react";
import { HiOutlineDotsHorizontal } from "react-icons/hi";

interface Chat {
  id: string;
  content: string;
  timestamp: Date;
  folderId?: string;
}

interface Folder {
  id: string;
  name: string;
  chatIds: string[];
}

interface FolderAccordionProps {
  folders: Folder[];
  chats: Chat[];
  onEditFolderName: (folderId: string, newName: string) => void;
  onDeleteFolder: (folderId: string) => void;
  onUpdateFolderContent: (chatId: string, folderId: string) => void;
  onRenameChat: (chatId: string, newName: string) => void;
  onDeleteChat: (chatId: string) => void;
}

const FolderAccordion: React.FC<FolderAccordionProps> = ({
  folders,
  chats,
  onEditFolderName,
  onDeleteFolder,
  onUpdateFolderContent,
  onRenameChat,
  onDeleteChat,
}) => {
  const [editingFolderId, setEditingFolderId] = useState<string | null>(null);
  const [newFolderName, setNewFolderName] = useState<string>("");
  const [editingChatId, setEditingChatId] = useState<string | null>(null);
  const [newChatName, setNewChatName] = useState<string>("");
  const [dragOverFolderId, setDragOverFolderId] = useState<string | null>(null);

  const handleFolderRenameSubmit = (folderId: string) => {
    if (newFolderName.trim() !== "") {
      onEditFolderName(folderId, newFolderName.trim());
    }
    setEditingFolderId(null);
    setNewFolderName("");
  };

  const handleChatRenameSubmit = (chatId: string) => {
    if (newChatName.trim() !== "") {
      onRenameChat(chatId, newChatName.trim());
    }
    setEditingChatId(null);
    setNewChatName("");
  };

  const handleDragOver = (e: React.DragEvent, folderId: string) => {
    e.preventDefault();
    setDragOverFolderId(folderId);
  };

  const handleDragLeave = () => {
    setDragOverFolderId(null);
  };

  const handleDrop = (e: React.DragEvent, folderId: string) => {
    e.preventDefault();
    setDragOverFolderId(null);

    const chatId = e.dataTransfer.getData("text/plain");
    if (!chatId) return;

    // 检查是否已经在这个文件夹中
    const targetFolder = folders.find(f => f.id === folderId);
    if (targetFolder?.chatIds.includes(chatId)) return;

    onUpdateFolderContent(chatId, folderId);
  };

  return (
    <Accordion allowMultiple>
      {folders.map((folder) => {
        const folderChats = chats.filter(chat => folder.chatIds.includes(chat.id));

        return (
          <AccordionItem
            key={folder.id}
            onDragOver={(e) => handleDragOver(e, folder.id)}
            onDragLeave={handleDragLeave}
            onDrop={(e) => handleDrop(e, folder.id)}
            border={dragOverFolderId === folder.id ? "2px dashed blue" : undefined}
            bg={dragOverFolderId === folder.id ? "blue.50" : undefined}
            transition="all 0.2s"
          >
            <h2>
              <AccordionButton>
                <Flex align="center" justify="space-between" w="full">
                  {editingFolderId === folder.id ? (
                    <Input
                      value={newFolderName}
                      onChange={(e) => setNewFolderName(e.target.value)}
                      onBlur={() => handleFolderRenameSubmit(folder.id)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          handleFolderRenameSubmit(folder.id);
                        }
                      }}
                      autoFocus
                      size="sm"
                      placeholder="Rename folder"
                    />
                  ) : (
                    <Text
                      flex="1"
                      textAlign="left"
                      onDoubleClick={() => {
                        setEditingFolderId(folder.id);
                        setNewFolderName(folder.name);
                      }}
                    >
                      {folder.name} ({folderChats.length})
                    </Text>
                  )}
                  <Menu>
                    <MenuButton
                      as={IconButton}
                      icon={<HiOutlineDotsHorizontal />}
                      aria-label="Folder Options"
                      variant="ghost"
                      size="sm"
                      _hover={{ bg: "gray.300" }}
                    />
                    <MenuList zIndex="popover">
                      <MenuItem onClick={() => {
                        setEditingFolderId(folder.id);
                        setNewFolderName(folder.name);
                      }}>
                        Rename
                      </MenuItem>
                      <MenuItem onClick={() => onDeleteFolder(folder.id)}>
                        Delete
                      </MenuItem>
                    </MenuList>
                  </Menu>
                </Flex>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel>
              {folderChats.length > 0 ? (
                folderChats.map((chat) => (
                  <Box
                    key={chat.id}
                    p={2}
                    mb={2}
                    bg="white"
                    borderRadius="md"
                    boxShadow="sm"
                  >
                    <Flex justify="space-between" align="center">
                      {editingChatId === chat.id ? (
                        <Input
                          value={newChatName}
                          onChange={(e) => setNewChatName(e.target.value)}
                          onBlur={() => handleChatRenameSubmit(chat.id)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              handleChatRenameSubmit(chat.id);
                            }
                          }}
                          autoFocus
                          size="sm"
                        />
                      ) : (
                        <Text>{chat.content}</Text>
                      )}
                      <Menu>
                        <MenuButton
                          as={IconButton}
                          icon={<HiOutlineDotsHorizontal />}
                          aria-label="Chat Options"
                          variant="ghost"
                          size="sm"
                          _hover={{ bg: "gray.300" }}
                        />
                        <MenuList zIndex="popover">
                          <MenuItem
                            onClick={() => {
                              setEditingChatId(chat.id);
                              setNewChatName(chat.content);
                            }}
                          >
                            Rename
                          </MenuItem>
                          <MenuItem onClick={() => onDeleteChat(chat.id)}>
                            Delete
                          </MenuItem>
                        </MenuList>
                      </Menu>
                    </Flex>
                  </Box>
                ))
              ) : (
                <Text fontSize="sm" color="gray.500">
                  Drag and drop chats here
                </Text>
              )}
            </AccordionPanel>
          </AccordionItem>
        );
      })}
    </Accordion>
  );
};

export default FolderAccordion;