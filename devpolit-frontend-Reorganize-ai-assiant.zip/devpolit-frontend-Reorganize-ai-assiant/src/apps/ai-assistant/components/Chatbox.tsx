import React, { useState } from "react";
import {
  Box,
  Flex,
  Input,
  IconButton,
  Text,
  Avatar,
  InputGroup,
  InputLeftElement,
  Select,
  useBreakpointValue,
} from "@chakra-ui/react";
import { FaPaperPlane, FaUpload, FaPlus } from "react-icons/fa";
import { IoCreateOutline } from "react-icons/io5";

interface ChatBoxProps {
  isSidebarOpen: boolean;
  onCreateChat: () => void; // 添加回调属性
}

const ChatBox: React.FC<ChatBoxProps> = ({ isSidebarOpen, onCreateChat }) => {
  const [inputValue, setInputValue] = useState("");
  const [selectedModel, setSelectedModel] = useState("gpt-3.5");

  // 动态计算 ChatBox 宽度
  const sidebarWidth = useBreakpointValue({ base: "0px", md: "300px" });
  const chatBoxWidth = isSidebarOpen
    ? `calc(100vw - ${sidebarWidth})`
    : "100vw";

  // 处理消息发送
  const handleSendMessage = () => {
    if (inputValue.trim()) {
      console.log("Sent message:", inputValue);
      setInputValue(""); // 清空输入框
    }
  };

  // 处理模型选择
  const handleModelChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedModel(event.target.value);
    console.log("Selected model:", event.target.value);
  };

  return (
    <Box
      w={chatBoxWidth} // 根据 sidebar 动态调整宽度
      h="100vh"
      bg="white"
      transition="all 0.3s ease" // 添加过渡动画
      display="flex"
      flexDirection="column" // 确保主内容和输入框布局正确
    >
      {/* Header Section */}
      <Flex
        justify="space-between"
        align="center"
        p={4}
        borderBottom="1px solid gray"
        bg="white"
        h="73px"
      >
        <Flex align="center" ml={"50px"}>
          {/* 左侧：Create New Chat 按钮（当 Sidebar 关闭时显示） */}
          {!isSidebarOpen && (
              <IconButton
                aria-label="Create New"
                icon={<IoCreateOutline />}
                onClick={onCreateChat} // 点击时调用回调
                _hover={{ bg: "blue.400" }}
                color="black"
                fontSize="30px"
              />
          )}

          {/* 模型选择器 */}
          <Select
            w="200px"
            ml={"10px"}
            placeholder="Select Model"
            value={selectedModel}
            onChange={handleModelChange}
          >
            <option value="model1">Model 1</option>
            <option value="model2">Model 2</option>
          </Select>
        </Flex>

        {/* 右侧：用户头像 */}
        <Avatar
          name="User"
          src="https://bit.ly/dan-abramov"
          size="md"
          bg="gray.200"
        />
      </Flex>

      {/* Main Content */}
      <Flex
        flex="1" // 主内容填充剩余空间
        justify="center"
        align="center"
        bg="white"
      >
        <Text fontSize="2xl" fontWeight="bold" mb={4}>
          What can I help you with today?
        </Text>
      </Flex>

      {/* Input Box */}
      <Flex
        justify="center"
        px={6}
        py={4}
        bg="white"
      >
        <Flex
          w="90%"
          maxW="600px"
          bg="gray.100"
          p={4}
          borderRadius="30px"
          align="center"
          boxShadow="sm"
        >
          {/* Upload Icon */}
          <IconButton
            aria-label="Upload File"
            icon={<FaUpload />}
            variant="ghost"
            mr={2}
            size="md"
          />

          {/* Input */}
          <InputGroup flex="1">
            <InputLeftElement
              pointerEvents="none"
              children={<Text color="gray.500">+</Text>}
            />
            <Input
              placeholder="Please enter your question here"
              bg="gray.100"
              border="none"
              focusBorderColor="transparent"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
            />
          </InputGroup>

          {/* Send Icon */}
          <IconButton
            aria-label="Send Message"
            icon={<FaPaperPlane />}
            variant="ghost"
            ml={2}
            size="md"
            onClick={handleSendMessage} // 点击发送消息
            isDisabled={!inputValue.trim()} // 输入为空时禁用
          />
        </Flex>
      </Flex>
    </Box>
  );
};

export default ChatBox;
