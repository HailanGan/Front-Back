import React from "react";
import { Flex, IconButton, Text, Tooltip } from "@chakra-ui/react";
import { FaFolder } from "react-icons/fa6";
import { MdOutlineCreateNewFolder } from "react-icons/md";

interface FolderListHeaderProps {
  onAddFolder: () => void;
}

const FolderListHeader: React.FC<FolderListHeaderProps> = ({ onAddFolder }) => {
  return (
    <Flex align="center" justify="space-between" mb={"5px"}>
      <Flex align="center">
        <FaFolder size="30px" color="blue" />
        <Text ml={2} fontSize="md" fontWeight="bold">
          Project
        </Text>
      </Flex>
      {/* Tooltip wrapping the IconButton */}
      <Tooltip label="Create New Project" fontSize="sm">
        <IconButton
          aria-label="Add New Folder"
          icon={<MdOutlineCreateNewFolder size="30px" />}
          onClick={onAddFolder}
          variant="ghost"
          color="black"
          _hover={{ bg: "blue.100" }}
        />
      </Tooltip>
    </Flex>
  );
};

export default FolderListHeader;
