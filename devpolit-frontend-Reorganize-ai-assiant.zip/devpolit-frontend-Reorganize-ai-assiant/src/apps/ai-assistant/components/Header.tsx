import React from "react";
import {
  Flex,
  IconButton,
  Input,
  InputGroup,
  InputLeftElement,
  Tooltip,
  Box,
  List,
  ListItem,
} from "@chakra-ui/react";
import { HamburgerIcon, SearchIcon } from "@chakra-ui/icons";
import { IoCreateOutline } from "react-icons/io5";

interface Message {
  id?: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  folderId?: string;
}

interface HeaderProps {
  toggleSidebar: () => void;
  onCreateChat: () => void;
  onSearch: (query: string) => void;
  searchResults: Message[];
}

const Header: React.FC<HeaderProps> = ({
  toggleSidebar,
  onCreateChat,
  onSearch,
  searchResults,
}) => {
  return (
    <Box>
      <Flex
        justify="space-between"
        align="center"
        p={4}
        color="white"
        borderBottom="1px solid gray"
      >
        <Tooltip label="Close Menu" fontSize="sm">
          <IconButton
            aria-label="Toggle Sidebar"
            icon={<HamburgerIcon />}
            onClick={toggleSidebar}
            _hover={{ bg: "blue.400" }}
            color="black"
            fontSize="30px"
          />
        </Tooltip>

        <Box flex="1" mx={4} position="relative">
          <InputGroup>
            <InputLeftElement pointerEvents="none">
              <SearchIcon color="gray.300" />
            </InputLeftElement>
            <Input
              placeholder="Search..."
              bg="white"
              color="black"
              borderRadius="30px"
              _placeholder={{ color: "gray.500" }}
              onChange={(e) => onSearch(e.target.value)}
            />
          </InputGroup>

          {searchResults.length > 0 && (
            <List
              bg="white"
              borderRadius="md"
              mt={2}
              boxShadow="md"
              position="absolute"
              zIndex={10}
              color="black"
              w="100%"
              maxH="200px"
              overflowY="auto"
            >
              {searchResults.map((result, index) => (
                <ListItem
                  key={index}
                  p={2}
                  _hover={{ bg: "gray.100" }}
                  cursor="pointer"
                >
                  {result.content}
                </ListItem>
              ))}
            </List>
          )}
        </Box>

        <Tooltip label="Create New Chat" fontSize="sm">
          <IconButton
            aria-label="Create New"
            icon={<IoCreateOutline />}
            onClick={onCreateChat}
            _hover={{ bg: "blue.400" }}
            color="black"
            fontSize="30px"
          />
        </Tooltip>
      </Flex>
    </Box>
  );
};

export default Header;