import React from "react";
import { Box, Text, VStack, List, Heading } from "@chakra-ui/react";
import ChatItem from "./ChatItem";

// 统一的消息接口
interface Chat {
  id: string;  // 保持 id 为必需
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  folderId?: string;
}

interface ChatHistoryProps {
  chatList: Chat[];
  onRenameChat: (chatId: string, newName: string) => void;
  onDeleteChat: (chatId: string) => void;
}

const groupChatsByDate = (chatList: Chat[]) => {
  const now = new Date();

  return {
    today: chatList.filter(
      (chat) => chat.timestamp.toDateString() === now.toDateString()
    ),
    yesterday: chatList.filter(
      (chat) =>
        chat.timestamp.toDateString() ===
        new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1).toDateString()
    ),
    lastSevenDays: chatList.filter((chat) => {
      const diff = now.getTime() - chat.timestamp.getTime();
      return diff > 24 * 60 * 60 * 1000 && diff <= 7 * 24 * 60 * 60 * 1000;
    }),
  };
};

const ChatHistory: React.FC<ChatHistoryProps> = ({
  chatList,
  onRenameChat,
  onDeleteChat,
}) => {
  if (!chatList || chatList.length === 0) {
    return (
      <Box p={4}>
        <Text fontSize="sm" color="gray.500" textAlign="center">
          No chats available. Click "Create New Chat" to start.
        </Text>
      </Box>
    );
  }

  const groupedChats = groupChatsByDate(chatList);

  return (
    <Box p={4}>
      <VStack align="stretch" spacing={4}>
        {/* Today */}
        {groupedChats.today.length > 0 && (
          <Box>
            <Heading size="sm" mb={2}>
              Today
            </Heading>
            <List spacing={2}>
              {groupedChats.today.map((chat) => (
                <ChatItem
                  key={chat.id}
                  chat={chat}
                  onRenameChat={(newName) => onRenameChat(chat.id, newName)}
                  onDeleteChat={() => onDeleteChat(chat.id)}
                />
              ))}
            </List>
          </Box>
        )}

        {/* Yesterday */}
        {groupedChats.yesterday.length > 0 && (
          <Box>
            <Heading size="sm" mb={2}>
              Yesterday
            </Heading>
            <List spacing={2}>
              {groupedChats.yesterday.map((chat) => (
                <ChatItem
                  key={chat.id}
                  chat={chat}
                  onRenameChat={(newName) => onRenameChat(chat.id, newName)}
                  onDeleteChat={() => onDeleteChat(chat.id)}
                />
              ))}
            </List>
          </Box>
        )}

        {/* Last 7 Days */}
        {groupedChats.lastSevenDays.length > 0 && (
          <Box>
            <Heading size="sm" mb={2}>
              Last 7 Days
            </Heading>
            <List spacing={2}>
              {groupedChats.lastSevenDays.map((chat) => (
                <ChatItem
                  key={chat.id}
                  chat={chat}
                  onRenameChat={(newName) => onRenameChat(chat.id, newName)}
                  onDeleteChat={() => onDeleteChat(chat.id)}
                />
              ))}
            </List>
          </Box>
        )}
      </VStack>
    </Box>
  );
};

export default ChatHistory;