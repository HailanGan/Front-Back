import React, { useState } from "react";
import { Box, IconButton, Divider } from "@chakra-ui/react";
import { HamburgerIcon } from "@chakra-ui/icons";
import Header from "./Header";
import ChatHistory from "./ChatHistory";
import FolderListSection from "./FolderListSection";
import ChatHistoryHeader from "./ChatHistoryHeader";

interface Chat {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  folderId?: string;
}

interface Folder {
  id: string;
  name: string;
  chatIds: string[];
}

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
  onSearch: (query: string) => void;
  searchResults: Chat[];
}

const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  toggleSidebar,
  onSearch,
  searchResults
}) => {
  const [chatList, setChatList] = useState<Chat[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);

  // 新建聊天逻辑
  const handleCreateChat = () => {
    const newChat: Chat = {
      id: Date.now().toString(),
      content: `Chat ${chatList.length + 1}`,
      role: 'assistant',
      timestamp: new Date(),
    };
    setChatList([newChat, ...chatList]);
  };

  // 文件夹管理逻辑
  const handleCreateFolder = () => {
    const newFolder: Folder = {
      id: Date.now().toString(),
      name: `New Folder ${folders.length + 1}`,
      chatIds: []
    };
    setFolders([...folders, newFolder]);
  };

  const handleRenameFolder = (folderId: string, newName: string) => {
    setFolders(prevFolders =>
      prevFolders.map(folder =>
        folder.id === folderId ? { ...folder, name: newName } : folder
      )
    );
  };

  const handleDeleteFolder = (folderId: string) => {
    setFolders(prevFolders => prevFolders.filter(folder => folder.id !== folderId));
  };

  const handleAddChatToFolder = (chatId: string, folderId: string) => {
    setFolders(prevFolders =>
      prevFolders.map(folder =>
        folder.id === folderId
          ? { ...folder, chatIds: [...folder.chatIds, chatId] }
          : folder
      )
    );
  };

  return (
    <Box>
      {isOpen && (
        <Box
          w="300px"
          h="100vh"
          bg="gray.100"
          position="fixed"
          top="0"
          left="0"
          overflowY="auto"
          boxShadow="lg"
        >
          <Header
            toggleSidebar={toggleSidebar}
            onCreateChat={handleCreateChat}
            onSearch={onSearch}
            searchResults={searchResults}
          />

          <Divider />

          <FolderListSection
            folders={folders}
            chats={chatList}
            onCreateFolder={handleCreateFolder}
            onRenameFolder={handleRenameFolder}
            onDeleteFolder={handleDeleteFolder}
            onAddChatToFolder={handleAddChatToFolder}
            onRenameChat={(id: string, newName: string) => {
              setChatList(prevChats =>
                prevChats.map(chat =>
                  chat.id === id ? { ...chat, content: newName } : chat
                )
              );
            }}
            onDeleteChat={(id: string) => {
              setChatList(prevChats => prevChats.filter(chat => chat.id !== id));
              // 同时从所有文件夹中移除该聊天
              setFolders(prevFolders =>
                prevFolders.map(folder => ({
                  ...folder,
                  chatIds: folder.chatIds.filter(chatId => chatId !== id)
                }))
              );
            }}
          />

          <Divider />

          <ChatHistoryHeader onCreateChat={handleCreateChat} />

          <ChatHistory
            chatList={chatList.filter(chat => !chat.folderId)} // 只显示未分类的聊天
            onRenameChat={(id: string, newName: string) => {
              setChatList(prevChats =>
                prevChats.map(chat =>
                  chat.id === id ? { ...chat, content: newName } : chat
                )
              );
            }}
            onDeleteChat={(id: string) => {
              setChatList(prevChats => prevChats.filter(chat => chat.id !== id));
            }}
          />
        </Box>
      )}

      {!isOpen && (
        <IconButton
          aria-label="Open Sidebar"
          icon={<HamburgerIcon />}
          onClick={toggleSidebar}
          position="fixed"
          top={"17px"}
          left={"15px"}
          color="black"
          fontSize="30px"
        />
      )}
    </Box>
  );
};

export default Sidebar;