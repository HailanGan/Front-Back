import React, { useState, useRef, useEffect } from 'react';
import {
  Box,
  VStack,
  HStack,
  Input,
  IconButton,
  Text,
  Avatar,
  Flex,
  useColorModeValue,
  useToast,
  Select,
  Heading,
} from '@chakra-ui/react';
import { IoMdSend } from 'react-icons/io';
import Sidebar from './Sidebar';
import { chatApi, folderApi, ChatWebSocket } from "../../../services/api";

// Define available models
const AVAILABLE_MODELS = [
  { value: 'gpt-3.5-turbo', label: 'GPT-3.5 Turbo' },
  { value: 'gpt-4', label: 'GPT-4' },
  { value: 'claude-3-opus', label: 'Claude 3 Opus' },
  { value: 'claude-3-sonnet', label: 'Claude 3 Sonnet' },
  { value: 'claude-3-haiku', label: 'Claude 3 Haiku' },
];

interface Chat {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  folderId?: string;
}

const IntegratedChat: React.FC = () => {
  // State management
  const [messages, setMessages] = useState<Chat[]>([]);
  const [input, setInput] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [searchResults, setSearchResults] = useState<Chat[]>([]);
  const [selectedModel, setSelectedModel] = useState(AVAILABLE_MODELS[0].value);
  const [webSocket] = useState(new ChatWebSocket());
  const toast = useToast();

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Theme
  const bgColor = useColorModeValue('white', 'gray.800');
  const borderColor = useColorModeValue('gray.200', 'gray.600');
  const headerBgColor = useColorModeValue('gray.100', 'gray.700');

  // Initialize WebSocket and load chat history
  useEffect(() => {
    loadChatHistory();
    webSocket.connect();

    webSocket.onMessage((data) => {
      const newMessage: Chat = {
        id: data.id || Date.now().toString(), // 确保总是有 id
        role: 'assistant',
        content: data.message,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, newMessage]);
    });

    return () => {
      webSocket.disconnect();
    };
  }, []);

  // Load chat history
  const loadChatHistory = async () => {
    try {
      const history = await chatApi.getHistory();
      if (history.length > 0) {
        setMessages(history);
      } else {
        // 如果没有历史记录，设置默认欢迎消息
        setMessages([{
          id: Date.now().toString(),
          role: 'assistant',
          content: 'Hello! How can I help you today?',
          timestamp: new Date(),
        }]);
      }
    } catch (error) {
      console.error('Failed to load chat history:', error);
      // 更详细的错误信息
      if (error instanceof Error) {
        toast({
          title: 'Error loading chat history',
          description: error.message,
          status: 'error',
          duration: 5000,
          isClosable: true,
        });
      }
      // 设置默认消息，即使加载失败也能让用户使用
      setMessages([{
        id: Date.now().toString(),
        role: 'assistant',
        content: 'Hello! How can I help you today?',
        timestamp: new Date(),
      }]);
    }
  };

  // Auto-scroll effect
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Message handling
  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Chat = {
      id: Date.now().toString(), // 使用时间戳作为临时 ID
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');

    try {
      // Include model selection when sending message
      webSocket.sendMessage(input, { model: selectedModel });
    } catch (error) {
      console.error('Failed to send message:', error);
      toast({
        title: 'Error sending message',
        status: 'error',
        duration: 3000,
      });
    }
  };

  // Search handling
  const handleSearch = (query: string) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    const results = messages.filter(msg =>
      msg.content.toLowerCase().includes(query.toLowerCase())
    );

    setSearchResults(results);
  };

  // Sidebar toggle
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // Handle model selection change
  const handleModelChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedModel(e.target.value);
    toast({
      title: 'Model Changed',
      description: `Selected model: ${e.target.value}`,
      status: 'info',
      duration: 2000,
      isClosable: true,
    });
  };

  return (
    <Box h="100vh" position="relative">
      <Sidebar
        isOpen={isSidebarOpen}
        toggleSidebar={toggleSidebar}
        onSearch={handleSearch}
        searchResults={searchResults}
      />

      <Box
        ml={isSidebarOpen ? "300px" : "60px"}
        width={isSidebarOpen ? "calc(100% - 300px)" : "calc(100% - 60px)"}
        transition="all 0.3s"
        h="100vh"
        bg="gray.50"
      >
        {/* New Header with Model Selection */}
        <HStack
          bg={headerBgColor}
          p={4}
          justifyContent="space-between"
          alignItems="center"
          boxShadow="sm"
        >
          <Heading size="md">AI Chat</Heading>
          <HStack>
            <Text>Model:</Text>
            <Select
              value={selectedModel}
              onChange={handleModelChange}
              width="200px"
              bg={bgColor}
            >
              {AVAILABLE_MODELS.map((model) => (
                <option key={model.value} value={model.value}>
                  {model.label}
                </option>
              ))}
            </Select>
          </HStack>
        </HStack>

        <VStack
          spacing={4}
          p={4}
          pb="80px"
          overflowY="auto"
          h="calc(100vh - 120px)" // Adjust height to account for header and input
        >
          {messages.map((message) => (
            <Flex
              key={message.id}
              w="full"
              justify={message.role === 'user' ? 'flex-end' : 'flex-start'}
            >
              <HStack
                maxW="80%"
                bg={message.role === 'user' ? 'blue.500' : bgColor}
                color={message.role === 'user' ? 'white' : 'inherit'}
                p={4}
                borderRadius="lg"
                boxShadow="sm"
              >
                {message.role === 'assistant' && (
                  <Avatar size="sm" name="AI Assistant" bg="blue.500" />
                )}
                <Text>{message.content}</Text>
              </HStack>
            </Flex>
          ))}
          <div ref={messagesEndRef} />
        </VStack>

        <HStack
          p={4}
          bg={bgColor}
          borderTop="1px"
          borderColor={borderColor}
          position="fixed"
          bottom={0}
          width={isSidebarOpen ? "calc(100% - 300px)" : "calc(100% - 60px)"}
          right={0}
          transition="all 0.3s"
        >
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleSend();
              }
            }}
          />
          <IconButton
            aria-label="Send message"
            icon={<IoMdSend />}
            colorScheme="blue"
            onClick={handleSend}
          />
        </HStack>
      </Box>
    </Box>
  );
};

export default IntegratedChat;