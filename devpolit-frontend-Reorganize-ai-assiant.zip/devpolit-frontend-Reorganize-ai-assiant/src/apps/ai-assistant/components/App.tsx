import React, { useState } from "react";
import Sidebar from "./Sidebar";
import ChatBox from "./Chatbox";

const App: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div>
      {/* Sidebar */}
      <Sidebar isOpen={isSidebarOpen}
               toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} onSearch={function (query: string): void {
          throw new Error("Function not implemented.");
      }} searchResults={[]} />

      {/* ChatBox */}
      <ChatBox isSidebarOpen={isSidebarOpen} onCreateChat={function (): void {
          throw new Error("Function not implemented.");
      }} />
    </div>
  );
};

export default App;
