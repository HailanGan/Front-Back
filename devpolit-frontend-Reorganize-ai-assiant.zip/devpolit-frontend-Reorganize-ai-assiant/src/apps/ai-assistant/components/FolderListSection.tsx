import React from "react";
import { Box, Text } from "@chakra-ui/react";
import FolderAccordion from "./FolderAccordion";
import FolderListHeader from "./FolderListHeader";

interface Chat {
  id: string;
  content: string;
  timestamp: Date;
  folderId?: string;
}

interface Folder {
  id: string;
  name: string;
  chatIds: string[];
}

interface FolderListSectionProps {
  folders: Folder[];
  chats: Chat[];
  onCreateFolder: () => void;
  onRenameFolder: (folderId: string, newName: string) => void;
  onDeleteFolder: (folderId: string) => void;
  onAddChatToFolder: (chatId: string, folderId: string) => void;
  onRenameChat: (chatId: string, newName: string) => void;
  onDeleteChat: (chatId: string) => void;
}

const FolderListSection: React.FC<FolderListSectionProps> = ({
  folders,
  chats,
  onCreateFolder,
  onRenameFolder,
  onDeleteFolder,
  onAddChatToFolder,
  onRenameChat,
  onDeleteChat
}) => {
  return (
    <Box p={4}>
      <FolderListHeader onAddFolder={onCreateFolder} />

      {folders.length === 0 ? (
        <Text fontSize="sm" color="gray.500" textAlign="center" mt={4}>
          No Projects Available.
        </Text>
      ) : (
        <FolderAccordion
          folders={folders}
          chats={chats}
          onEditFolderName={onRenameFolder}
          onDeleteFolder={onDeleteFolder}
          onUpdateFolderContent={onAddChatToFolder}
          onRenameChat={onRenameChat}
          onDeleteChat={onDeleteChat}
        />
      )}
    </Box>
  );
};

export default FolderListSection;