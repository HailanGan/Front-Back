import React from "react";
import { Flex, Text, IconButton } from "@chakra-ui/react";
import { FaHistory } from "react-icons/fa";

interface HeaderProps {
  onCreateChat: () => void;
}

const ChatHistoryHeader: React.FC<HeaderProps> = ({ onCreateChat }) => {
  return (
    <Flex align="center" justify="space-between" mb={"5px"} ml={"15px"} >
      <Flex align="center">
        <FaHistory size="30px" color="blue" />
        <Text ml={2} fontSize="md" fontWeight="bold">
          Chat History
        </Text>
      </Flex>
    </Flex>
  );
};

export default ChatHistoryHeader;
