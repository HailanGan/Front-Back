import React from "react";
import { Flex, Image } from "@chakra-ui/react";

const Logo: React.FC = () => {
  return (
    <Flex pl={"50px"}>
      <Image src="/src/assets/images/Logo.png" alt="Logo" height="40px" />
    </Flex>
  );
};

export default Logo;
