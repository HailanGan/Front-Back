import React, { useState } from "react";
import { Box } from "@chakra-ui/react";
import Sidebar from "../components/Sidebar";
import ChatBox from "../components/Chatbox";

const Main: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false); // 控制 Sidebar 的状态

  // 切换 Sidebar 的显示状态
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <Box display="flex" h="100vh" overflow="hidden">
      {/* Sidebar */}
      <Sidebar isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />

      {/* ChatBox */}
      <Box
        flex="1" // 占满剩余空间
        transition="all 0.3s ease" // 平滑过渡效果
        ml={isSidebarOpen ? "300px" : "0"} // 根据 Sidebar 状态调整左边距
        bg="gray.50" // ChatBox 背景
      >
        <ChatBox isSidebarOpen={isSidebarOpen} />
      </Box>
    </Box>
  );
};

export default Main;
